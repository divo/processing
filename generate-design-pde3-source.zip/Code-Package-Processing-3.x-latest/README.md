This code package still needs to be updated to Processing 3.x and is work in progress! Most of it should work by now.
===============================================

Generative Design Code Package (for Processing-3.x)
===========================

Hi. This GitHub repository completes the book [Generative Design](http://www.generative-gestaltung.de). It offers direct access to all [Processing](http://processing.org/) source code for the software described in the book.

http://www.generative-gestaltung.de

**This code package still needs to be updated to Processing 3.x. We do our best to finish it as soon as possible.**

**Authors**
- Hartmut Bohnacker
- [Benedikt Groß](http://benedikt-gross.de)
- [Julia Laub](http://www.onformative.com/)
- [Claudius Lazzeroni](http://www.lazzeroni.de/), editor

We hope by using GitHub to host the source code of the book, it will be easier and more swift to manage corrections. Please use the GitHub issues for bug reports, typos, suggestions, etc. You are also very welcome to fork the repo, make corrections on your own and submit a pull request. Please keep pull requests to an easy digestible size, so that the review process can be quick and uncomplicated.

All of the book's source code is licensed under the [Apache License Version 2.0](http://www.apache.org/licenses/LICENSE-2.0)
